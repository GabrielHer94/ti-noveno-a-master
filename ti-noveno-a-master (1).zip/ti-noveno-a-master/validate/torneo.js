const { body } = require('express-validator')
const requestValidator = require('../helpers/requestValidator')
const exists = require('../helpers/exists')

const create = [
    body('torneo').notEmpty(),
    body('torneo.nombre').notEmpty().custom(async(nombre) => {
        if(await exists('nombre', nombre, 'torneos')) {
            throw Error('El nombre ya esta en uso')
        }
    }),
    body('torneo.descripcion').notEmpty(),
    body('torneo.ubicacion').notEmpty(),
    body('torneo.fecha_inicio').notEmpty(),
    body('torneo.fecha_fin').notEmpty(),
    body('torneo.deporte_id').notEmpty(),
    (req, res, next) => {
        requestValidator(req, res, next)
    }
]
const update = [
    body('id').notEmpty(),
    (req, res, next) => {
        requestValidator(req, res, next)
    }
]
module.exports = {
    create,
    update
}