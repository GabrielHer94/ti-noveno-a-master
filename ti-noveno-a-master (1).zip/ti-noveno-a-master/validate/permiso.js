const { body } = require('express-validator')
const requestValidator = require('../helpers/requestValidator')
const exists = require('../helpers/exists')


const create = [
    body('nombre').notEmpty().isString().custom(async (nombre) => {
        if(await exists('nombre',nombre,'permisos')){
            throw Error('El nombre ya esta en uso')
        }
    }),
    (req,res,next) => {
        requestValidator(req,res,next)
    }
]

const update = [
    body('id').notEmpty(),
    body('nombre').notEmpty(),
    (req,res,next) => {
        requestValidator(req,res,next)
    }
]
module.exports = {
    create,
    update
}