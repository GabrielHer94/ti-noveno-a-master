const { body } = require('express-validator')
const requestValidator = require('../helpers/requestValidator')
const exists = require('../helpers/exists')

const login = [
    body('email').notEmpty().isEmail(),
    body('password').notEmpty(),
    (req,res,next) => {
        requestValidator(req,res,next)
    }
]  
const register = [
    body('nombre').notEmpty().escape(),
    body('apellido_mat').notEmpty().isLength({ max: 30 }),
    body('apellido_pat').notEmpty().isLength({ max: 30 }),
    body('numero_tel').notEmpty().escape(),
    body('password').notEmpty().isString().isLength({ min: 8 }),
    body('email').notEmpty().isString().isEmail().custom(async (email) => {
        if(await exists('email',email,'users')){
            throw Error('El correo electrónico ya esta en uso')   
        }
    }).escape(),
    (req,res,next) => {
        requestValidator(req,res,next)
    }
]

const update = [
    body('id').notEmpty().isNumeric().escape(),
    (req,res,next) => {
        requestValidator(req,res,next)
    }
]

module.exports = {
    login,
    register,
    update
}