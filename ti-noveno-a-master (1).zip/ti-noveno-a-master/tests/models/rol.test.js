const { Rol } = require('../../models')

describe('El modelo roles',() => {
    test('Busca correctamente',async () => {
        let testPassed = true

        try {            
            const rol = await Rol.findAll({
                where: {
                    id : 1
                }
            })
        } catch (error) {
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
})