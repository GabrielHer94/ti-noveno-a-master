const {Equipo} = require('../../models')

describe('Modelo Equipo', () => {
    test('findById',async () => {
        let testPassed= true
        try{
            await Equipo.findOne({
                where : {
                    id : 1
                }
            })
        }catch(err){
            testPassed = false
            console.log(err)
        }
        expect(testPassed).toBeTruthy()
    })
})