const Connection = require('../../database/connection/connection')

test('La conexión se realiza correctamente',async () => {
    let connectionResult = true
    try{
        await Connection.create().authenticate()
    }catch(err){
        console.log(err)
        connectionResult = false
    }

    expect(connectionResult).toBe(true)
})

afterAll(() => {
    Connection.close()
})