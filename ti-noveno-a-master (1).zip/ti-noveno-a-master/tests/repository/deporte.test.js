require('dotenv').config()
const deporteRepository = require('../../repository/deporte')
const deporte = 'Baloncesto'
const deporteUpdate = 'Soccer'

describe('El repositorio deporte', () => {
    beforeAll(async () => {
        const deporteFromDB = await deporteRepository.findByName(deporte)
        if(deporteFromDB){
            await deporteFromDB.destroy()
        }
    })
    afterAll(async () => {
        const deporteFromDB = await deporteRepository.findByName(deporteUpdate)
        if(deporteFromDB){
            await deporteFromDB.destroy()
        }
    })
    test('Acción findAll',async () => {
        const value = await deporteRepository.findAll()
        let foundTest = false

        if(value.length !== undefined){
            foundTest = true
        }
        expect(foundTest).toBe(true)
    })
    
    test('Acción save', async () => {
        let passTest = true
        try{
            await deporteRepository.save(deporte)
        }catch(err){
            passTest = false
        }
        expect(passTest).toBe(true)
    })
    
    test('Acción findById',async () => {
        const deporteFromDB = await deporteRepository.findByName(deporte)
        let passTest = await deporteRepository.findById(deporteFromDB.id)
        expect(passTest).not.toBeNull()
    })

    test('Acción update', async () => {
        let deportePrevio = await deporteRepository.findByName(deporte)
        await deporteRepository.update({
            nombre : deporteUpdate
        },{
            id : deportePrevio.id
        })
        deportePrevio = await deporteRepository.findByName(deporte)
        expect(deportePrevio).toBe(null)
    })
})