const userRepository = require('../../repository/user')
const rolRepository = require('../../repository/rol')
const permisoRepository = require('../../repository/permiso')

describe('El repositorio user',() => {
    beforeAll(async () => {
        await permisoRepository.save({
            nombre : 'permiso.test'
        })
        const permiso = await permisoRepository.findByName('permiso.test')        
        const rol = await rolRepository.save({
            nombre : 'RolTest'
        })        
        await permiso.addRol(rol)
    })
    afterAll(async () => {
        const permiso = await permisoRepository.findByName('permiso.test')
        if(permiso){
            await permiso.destroy()
        }
        const rol = await rolRepository.findByName('RolTest')
        if(rol){
            await rol.destroy()
        }
    })
    test('findByEmail funciona correctamente',async () => {
        let testPassed = true
        try{
            await userRepository.findByEmail('eduardocazabalsalas@gmail.com')
        }catch(err){
            console.log(err)
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
})