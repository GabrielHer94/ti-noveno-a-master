const rolRepository = require('../../repository/rol')

const rol = {
    nombre : 'permiso.test'
}

describe('Repositorio rol',() => {
    beforeAll(async () => {
        const rolFromDb = await rolRepository.findByName(rol.nombre)
        if(rolFromDb){
            await rolFromDb.destroy()
        }
    })
    afterAll(async () => {
        const rolFromDb = await rolRepository.findByName(rol.nombre)
        if(rolFromDb){
            await rolFromDb.destroy()
        }
    }) 
    test('save', async () => {
        let testPassed = true
        try {
            const rolFromDb = await rolRepository.save(rol)
        } catch (error) {
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
    test('findByName',async () => {
        let testPassed = true
        try {
            const rol = await rolRepository.findByName('Administrador')
        } catch (error) {
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
})