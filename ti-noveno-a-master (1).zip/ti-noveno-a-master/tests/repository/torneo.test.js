const torneo = require('../../repository/torneo')

describe('El repositorio torneo',() => {
    test('Busca correctamente',async () => {
        let testPassed = true
        try {
            const torneos = await torneo.findAll()
        } catch (error) {
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
})