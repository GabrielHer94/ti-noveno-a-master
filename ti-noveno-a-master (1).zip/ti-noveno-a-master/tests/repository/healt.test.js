const bcrypt = require('bcrypt')
const userRepository = require('../../repository/user')
const healthRepository = require('../../repository/health')


describe('Repositorio Health', () => {
    beforeAll(async () => {
        const user = await userRepository.save({
            nombre: "HealthUser",
            apellido_pat: "test1",
            apellido_mat: "test2",
            numero_tel: "test25",
            password: bcrypt.hashSync('12345', bcrypt.genSaltSync()),
            email: 'test@health.com',
        })
    })
    afterAll(async () => {
        const user = await userRepository.findByEmail('test@health.com')
        if(user) {
            await user.destroy({
                force : true
            })
        }
    })
    test('save', async () => {
        let testPassed = true
        try {
            const user = await userRepository.findByEmail('test@health.com')
            await healthRepository.save({ estress: 100, ritmo_cardiaco: 60, wearable_id : user.id })
        } catch (error) {
            console.log(error)
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
    test('update', async () => {
        let testPassed = true
        try {
            const user = await userRepository.findByEmail('test@health.com')
            await healthRepository.update(1,{ estress: 100, ritmo_cardiaco: 60, user_id: user.id })
        } catch (error) {
            console.log(error)
            testPassed = false
        }
        expect(testPassed).toBeTruthy()
    })
})