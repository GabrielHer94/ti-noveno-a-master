const permisoRepository = require('../../repository/permiso')
const request = require('supertest')
const app = require('../../index')
const {server} = app
app.port = 10700
const permiso = {
    nombre : 'test.ejemplo'
}

describe('Controlador Permisos',() => {
    beforeAll(async () => {
        const permisoFromDb = await permisoRepository.findByName(permiso.nombre)
        if(permisoFromDb){
            await permisoFromDb.destroy()
        }
    })
    afterAll(async () => {
        const permisoFromDb = await permisoRepository.findByName('test.ejemplo1')
        if(permisoFromDb){
            await permisoFromDb.destroy()
        }
        app.close()
    })
    test('Acción index',async () => {
        const response = await request(server).get('/permisos')
        expect(response.ok).toBeTruthy()
    })
    test('Acción store',async () => {
        const response = await request(server)
                                .post('/permisos')
                                .send(permiso)
        expect(response.ok).toBeTruthy()
    })
    test('Acción update', async () => {
        const permisoFromDb = await permisoRepository.findByName(permiso.nombre)
        const response = await request(server)
                                .patch('/permisos')
                                .send({
                                    id : permisoFromDb.id,
                                    nombre : 'test.ejemplo1'
                                })
        expect(response.ok).toBeTruthy()
    })
})