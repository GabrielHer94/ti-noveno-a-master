const { save, findByEmail } = require('../../repository/user')
const bcrypt = require('bcrypt')
const app = require('../../index')
const {server} = app
const request = require('supertest')
app.port = 11020

const email = "eduardocazabalsalas@gmail.com"


describe('Acciónes del controlador auth', () => {
    beforeAll(async () => {
        let user = await findByEmail(email)
        if (!user) {
            await save({
                nombre: "Eduardo",
                apellido_pat: "Cazabal",
                apellido_mat: "Salas",
                numero_tel: "2482685655",
                password: bcrypt.hashSync('12345', bcrypt.genSaltSync()),
                email,
            })
        }
    })
    afterAll(async () => {
        let user = await findByEmail('jake@gmail.com')
        if(user){
            await user.destroy()
        }
        user = await findByEmail(email)
        if(user){
            await user.destroy()
        }
        app.close()
    })
    test('Acción login correcta', async () => {
        const response = await request(server)
            .post('/auth/login')
            .send({
                email,
                password: '12345'
            })

        expect(response.statusCode).toBe(200)
    })
    test('Acción registrar correcta', async () => {
        const response = await request(server)
            .post('/auth/register')
            .send({
                nombre: "Jake",
                apellido_pat: "Smith",
                apellido_mat: "Jones",
                numero_tel: "2482685655",
                password: "12345",
                email: "jake@gmail.com",
            })
        expect(response.statusCode).toBe(201)
    })
    test('Acción update correcta', async () => {
        const user = await findByEmail(email)
        const response = await request(server)
            .patch('/auth/update')
            .send({
                id: user.id,
                nombre: "Dayana",
                apellido_pat: "Diaz",
                apellido_mat: "Perez",
                numero_tel: "20439034",
                password: "12345"
            })
        expect(response.statusCode).toBe(200)
    })
    test('Acción index', async () => {
        const response = await request(server)
            .patch('/auth?limit=1')
        expect(response)
    })
})
