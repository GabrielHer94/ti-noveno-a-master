const request = require('supertest')
const deporteRepository = require('../../repository/deporte')
const app = require('../../index')
const { server } = app
app.port = 12050
const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwibm9tYnJlIjoiRWR1YXJkbyIsImFwZWxsaWRvX3BhdCI6IkNhemFiYWwiLCJhcGVsbGlkb19tYXQiOiJTYWxhcyIsImVtYWlsIjoiZWR1YXJkb2NhemFiYWxzYWxhc0BnbWFpbC5jb20iLCJudW1lcm9fdGVsIjoiMjQ4MjY4NTY1NSIsImNyZWF0ZWRBdCI6IjIwMjQtMDUtMDZUMTY6NTc6MTUuMDAwWiIsInVwZGF0ZWRBdCI6IjIwMjQtMDUtMDZUMTY6NTc6MTUuMDAwWiIsImlhdCI6MTcxNzg4NzQ3MX0.ZzN5lQK3GDLb-R-1-vqoZHABRau9Mul24HyVJO0Y8zc'

const deporte = {
    nombre: 'Volleyball'
}

describe('Controlador de deportes', () => {
    beforeAll(async () => {
        let deporteFromDB = await deporteRepository.findByName(deporte.nombre)
        if (deporteFromDB) {
            await deporteFromDB.destroy()
        }
        await deporteRepository.save(deporte.nombre)
    })
    afterAll(async () => {
        let deporteFromDB = await deporteRepository.findByName('Soccer')
        if (deporteFromDB) {
            await deporteFromDB.destroy()
        }
        deporteFromDB = await deporteRepository.findByName('Baloncesto')
        if(deporteFromDB){
            await deporteFromDB.destroy()
        }
        app.close()
    })
    test('Acción index', async () => {
        const response = await request(server)
            .get('/deportes') 
        expect(response.ok).toBeTruthy()
    })
    test('Acción store', async () => {
        const response = await request(server)
            .post('/deportes')
            .set('Authorization', token)
            .send({
                nombre : 'Baloncesto'
            })

        expect(response.statusCode).toBe(201)
    })
    test('Acción update', async () => {
        const deporteFromDB = await deporteRepository.findByName(deporte.nombre)
        const response = await request(server)
            .patch('/deportes')
            .set('Authorization', token)
            .send({
                nombre: 'Soccer',
                id: deporteFromDB.id
            })
        expect(response.ok).toBeTruthy()
    })
    test('Acción delete', async () => {
        const deporteFromDB = await deporteRepository.findByName('Soccer')
        const response = await request(server)
            .delete('/deportes')
            .set('Authorization', token)
            .send({
                id: deporteFromDB.id
            })
        console.log(response.statusCode)
        expect(response.ok).toBeTruthy()
    })
})
