const request = require('supertest')
const app = require('../../index')
const equipoRepository = require('../../repository/equipo')
const torneoRepository = require('../../repository/torneo')
app.port = 25000
const { server } = app
const equipos = []
let torneo

describe('Controlador partido', () => {
    beforeAll(async () => {
        equipos.push(await equipoRepository.save({
            nombre: 'local'
        }))
        equipos.push(await equipoRepository.save({
            nombre: 'visitante'
        }))
        torneo = await torneoRepository.save({
            nombre: 'Torneo Test',
            descripcion: 'Descripción test',
            ubicacion: 'ubicación test',
            fecha_inicio: '2002-09-01',
            fecha_fin: '2002-10-09',
            privado: false
        })
    })
    afterAll(async () => {
        for(const equipo of equipos){
            await equipoRepository.destroy(equipo.id,true)
        }
        app.close()
    })
    test('Acción store', async () => {
        const equipoUno = equipos[0]
        const equipoDos = equipos[1]
        const response = await request(server)
                                .post('/partidos')
                                .send({
                                    equipo_uno_id : equipoUno.id,
                                    equipo_dos_id : equipoDos.id,
                                    torneo_id : torneo.id
                                })
        expect(response.ok).toBeTruthy()
    })
})