const app = require('../../index')
const {server} = app
const rolRepository = require('../../repository/rol')
const request = require('supertest')
app.port= 13800

const rol = {
    nombre : 'rol_test'
}

describe('Controlador Rol',() => {
    beforeAll(async () => {
        const rolFromDb = await rolRepository.findByName(rol.nombre)
        if(rolFromDb){
            await rolFromDb.destroy() 
        }
        await rolRepository.save(rol)
    })
    afterAll(async () => {
        let rolFromDb = await rolRepository.findByName('rol_test_update')
        if(rolFromDb){
            await rolFromDb.destroy()
        }
        rolFromDb = await rolRepository.findByName('rol_test_store')
        if(rolFromDb){
            await rolFromDb.destroy()
        }
        app.close()
    })
    test('Acción index', async () => {
        const response = await request(server)
                            .get('/roles')
        expect(response.ok).toBeTruthy()
    })
    test('Acción store', async () => {
        const response = await request(server)
                            .post('/roles')
                            .send({
                                rol: {
                                    nombre : 'rol_test_store'
                                }
                            })
        expect(response.ok).toBeTruthy()
    })
    test('Acción update',async () => {
        const rolFromDb = await rolRepository.findByName(rol.nombre)
        const response = await request(server)
                                .patch('/roles')
                                .send({
                                    id: rolFromDb.id,
                                    nombre : 'rol_test_update'
                                })
        expect(response.ok).toBeTruthy()
    })
})