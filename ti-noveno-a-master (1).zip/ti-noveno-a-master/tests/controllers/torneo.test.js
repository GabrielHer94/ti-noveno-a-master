const request = require('supertest')
const app = require('../../index')
const { server } = app
const torneoRepository = require('../../repository/torneo')
const deporteRepository = require('../../repository/deporte')
app.port = 14011
const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwibm9tYnJlIjoiRWR1YXJkbyIsImFwZWxsaWRvX3BhdCI6IkNhemFiYWwiLCJhcGVsbGlkb19tYXQiOiJTYWxhcyIsImVtYWlsIjoiZWR1YXJkb2NhemFiYWxzYWxhc0BnbWFpbC5jb20iLCJudW1lcm9fdGVsIjoiMjQ4MjY4NTY1NSIsImNyZWF0ZWRBdCI6IjIwMjQtMDUtMDZUMTY6NTc6MTUuMDAwWiIsInVwZGF0ZWRBdCI6IjIwMjQtMDUtMDZUMTY6NTc6MTUuMDAwWiIsImlhdCI6MTcxNzg4NzQ3MX0.ZzN5lQK3GDLb-R-1-vqoZHABRau9Mul24HyVJO0Y8zc'

const torneoReq = {
    torneo: {
        nombre: 'Torneo Test',
        descripcion: 'Descripción test',
        ubicacion: 'ubicación test',
        fecha_inicio: '2002-09-01',
        fecha_fin: '2002-10-09',
        privado: false
    }
}

let deporte = {}

const torneos = []

describe('Controlador Torneo', () => {
    beforeAll(async () => {
        deporte = await deporteRepository.save("deporte test")
        torneos.push(await torneoRepository.save(torneoReq.torneo))
    })
    afterAll(async () => {
        deporte = await deporteRepository.findByName('deporte test')
        if(deporte){
            await deporteRepository.destroy(deporte.id, true)
        }
        app.close()
    })
    test('Acción index', async () => {
        const response = await request(server)
            .get('/torneos')
        expect(response.ok).toBeTruthy()
    })
    test('Acción store', async () => {
        const response = await request(server)
            .post('/torneos')
            .set('Authorization', token)
            .send({
                torneo: {
                    nombre: 'Torneo Test Store',
                    descripcion: 'Descripción test store',
                    ubicacion: 'ubicación test store',
                    fecha_inicio: '2002-09-01',
                    fecha_fin: '2002-10-09',
                    deporte_id: deporte.id,
                    privado: false
                },
                equipos: {
                    nombre: "Equipo test"
                }
            })
        expect(response.ok).toBeTruthy()
    })
    test('Acción update', async () => {
        const torneoFromDb = await torneoRepository.findByName('Torneo Test')
        const response = await request(server)
            .patch('/torneos')
            .set('Authorization', token)
            .send({
                id: torneoFromDb.id,
                status: 0
            })
        expect(response.ok).toBeTruthy()
    })
})
