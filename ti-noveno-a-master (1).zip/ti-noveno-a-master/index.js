const App = require('./app/app')

const app = new App()

app.listen()

module.exports = app