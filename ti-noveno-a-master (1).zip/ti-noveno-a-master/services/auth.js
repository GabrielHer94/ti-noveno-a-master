const rolRepository = require('../repository/rol')
const userRepository = require('../repository/user')
const crypt = require('../helpers/crypt')
const jwt = require('jsonwebtoken')
const {success,failure} = require('../helpers/result')
const { Op } = require('sequelize')

const authenticate = async ({email,password}) => {
    const user = await userRepository.findByEmail(email)
    if(!user){
        return failure('usuario no encontrado')
    }
    if(crypt.compare(password,user.password)){
        const { password, ...params } = user.dataValues
        const token = jwt.sign(params,process.env.SECRET_KEY)
        return success({
            user: {
                ...params
            },
            token
        })
    }
    return failure('Credenciales incorrectas')
    
}

const register = async ({nombre,apellido_mat,apellido_pat,email,numero_tel,password, rol }) => {
    const user = await userRepository.save({nombre,apellido_mat,apellido_pat,email,numero_tel,password})
    if(rol){
        rol = await rolRepository.findById(rol)
    }
    if(!rol){
        rol = await rolRepository.findByName('Usuario')
    }
    await user.addRol(rol)
    const userFields = user.dataValues
    delete userFields.password
    return userFields
}

const read = async ({ nombre , limit = 100, offset = 0}) => {
    const queryOptions = { 
        where : {}, 
    }
    if(nombre){
        queryOptions.where.nombre = {
            [Op.like] : `%${nombre}%`
        }
    }
    if(offset){
        offset = parseInt(offset)
        queryOptions.offset = offset
    }
    if(limit) {
        limit = parseInt(limit)
        queryOptions.limit = limit
    }
    console.log(queryOptions)
    if(nombre){
        return await userRepository.find(queryOptions)
    }
    return await userRepository.findAll()
}

module.exports = {
    authenticate,
    register,
    read
}