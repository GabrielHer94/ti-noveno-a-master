const { save } = require('../repository/wearable')

const create = async ({ model, ip_address, user_id }) => {
    await save({
        model,
        ip_address,
        user_id
    })
}

module.exports = {
    create
}