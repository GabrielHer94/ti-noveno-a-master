const partidoRepository = require('../repository/partido')

const create = async (equipos) => {
    console.log(equipos)
    await partidoRepository.save(equipos)
}

module.exports = {
    create
}