const rolRepository = require('../repository/rol')

const read = async ({ id }) => {
    if(id){
        return await rolRepository.findById(id)
    }
    return await rolRepository.findAll()
}

const create = async ({rol,permisos}) => {
    const rolFromDb = await rolRepository.save({
        nombre : rol.nombre
    })
    if(permisos){
        for(permiso of permisos){
            const permisoFromDB = rolRepository.findById(permiso)
            if(permisoFromDB){
                await rolFromDb.addPermiso(permiso)
            }
        }
    }
}

const update = async ({nombre,id}) => {
    await rolRepository.update({nombre},{
        id
    })
}

module.exports = {
    create,
    update,
    read
}