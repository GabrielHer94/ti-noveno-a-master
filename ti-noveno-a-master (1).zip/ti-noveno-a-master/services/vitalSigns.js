const vitalSignsRepository = require('../repository/vitalSigns')
const wearableRepository = require('../repository/wearable')

const read = async ({ wearable_id }) => {
    if(wearable_id){
        return await vitalSignsRepository.findByWearableId(wearable_id)
    }
    return await vitalSignsRepository.findAll()
}

const create = async ({ estres, ritmo_cardiaco, wearable_id }) => {
    await vitalSignsRepository.save({estres,ritmo_cardiaco,wearable_id})
}

const notifyToClients = async (io) => {
    const vitalSigns = await vitalSignsRepository.findAll()
    io.emit('changed-last-vital-signs', vitalSigns)
}

module.exports = {
    create,
    notifyToClients,
    read
}