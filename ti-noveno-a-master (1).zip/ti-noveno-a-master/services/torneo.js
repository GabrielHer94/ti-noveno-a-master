const torneoRepository = require('../repository/torneo')
const equipoRepository = require('../repository/equipo')
const formatter = require('../helpers/formatter')

const create = async (torneo, equipos) => {
   const {nombre,descripcion,ubicacion,fecha_inicio,fecha_fin,deporte_id,privado} = torneo
   const torneoFromDb = await torneoRepository.save({
        nombre,
        descripcion,
        ubicacion,
        fecha_inicio,
        fecha_fin,
        deporte_id,
        privado,
        createdAt : formatter(new Date())
    })
    if(equipos && equipos.length > 0){
        for(const value of equipos){
            const equipo = await equipoRepository.findById(value)
            if(equipo){
                await torneoFromDb.addEquipo(equipo)
                console.log('agregando equipo....')
            }
        }
    }
}

const update = async (torneo) => {
    torneo.updatedAt = formatter(new Date())
    let torneoLimpio = {}
    for(const key in torneo){
        if(torneo[key] !== undefined && torneo[key] !== null && key !== 'id'){
            torneoLimpio[key] = torneo[key]
        }
    }
    await torneoRepository.update(torneoLimpio,{
        id : torneo.id
    })
}

module.exports = {
    create,
    update,
}