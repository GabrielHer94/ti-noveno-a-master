const deporteRepository = require('../repository/deporte')

const create = async ({nombre}) => {
    await deporteRepository.save(nombre)
}

const update = async ({id,...deporte}) => {
    await deporteRepository.update(deporte,{id})
}   

const destroy = async (id) => {
    const model = await deporteRepository.findById(id)
    if(!model){
        return false
    }
    await model.destroy()
    return true
}

module.exports = {
    create,
    update,
    destroy
}