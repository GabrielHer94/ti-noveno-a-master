const permisoRepository = require('../repository/permiso')

const read = async ({ id }) => {
    if(id){
        return await permisoRepository.findById(id)
    }
    return await permisoRepository.findAll()
}

const create = async ({nombre}) => {
    await permisoRepository.save({nombre})
}

const update = async (permiso) =>{
    const {id, nombre} = permiso
    await permisoRepository.update({nombre},{
        id
    })
}

module.exports = {
   create,
   update,
   read
}