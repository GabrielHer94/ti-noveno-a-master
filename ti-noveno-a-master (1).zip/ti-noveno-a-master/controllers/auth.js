const userRepository = require('../repository/user')
const authService = require('../services/auth')
const crypt = require('../helpers/crypt')

const login = async (req, res) => {
    const result = await authService.authenticate(req.body)
    if(result.isSuccess){
        const user = result.value
        return res.status(200).json({
            message: 'Acceso Correcto',
            ...user
        })
    }
    res.status(401).json({
        message : 'Credeciales incorrectas'
    })
}

const register = async (req, res) => {
    try {
        delete req.body.rol
        const user = await authService.register(req.body)
        res.status(201).json({
            message: 'Usuario creado',
            user
        })
    } catch (err) {
        console.log(err)
        res.status(500).json({
            message: 'Contacta al administrador'
        })
    }
}

const update = async (req, res) => {
    try {
        const { id, ...params } = req.body
        if (params.password) {
            params.password = crypt.hash(params.password)
        }
        const user = await userRepository.findById(id)
        await user.update(params)
        return res.status(200).json({
            message: 'Usuario actualizado correctamente'
        })
    } catch (err) {
        res.status(500).json({
            message: 'Error, contacta al administrador'
        })
    }
}

const index = async (req, res) => {
    try {
        const users = await authService.read(req.query)
        res.status(200).json({
            users,
            total: users.length
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({
            message: 'Error, contacta al administrador'
        })
    }
}

const store = async (req,res) => {
    try {
        const user = await authService.register(req.body)
        res.status(201).json({
            message: 'Usuario creado',
            user
        })
    } catch (error) {
        res.status(500).json({
            message: 'Error, contacta al administrador'
        })
    }
}

module.exports = {
    login,
    register,
    update,
    index,
    store
}