const equipoRepository = require('../repository/equipo')

const index = async (req,res) => {
    const equipos = await equipoRepository.findAll(req.query)
    res.status(200).json({
        equipos,
        total : equipos.length
    })
}

const store = async (req,res) => {
    try {
        await equipoRepository.save(req.body)
        res.status(201).json({
            message: 'Equipo creado'
        })
    } catch (error) {
        res.status(501).json({
            message : 'Error, contacta al administrador'
        })
    }
}

module.exports = {
    index,
    store
}