const torneoService = require('../services/torneo')
const torneoRepository = require('../repository/torneo')

const index = async (req,res) => {
    try {
        const torneos = await torneoRepository.findAll(req.query)
        
        res.status(200).json({
            torneos,
            total: torneos.length
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error contacta al administrador'
        })
    }
}

const show = async (req, res) => {
    try {
        const torneo = await torneoRepository.findById(req.query.id)

        res.status(200).json({
            torneo
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error contacta al administrador'
        })
    }
}

const store = async (req,res) => {
    try {
        const { torneo, equipos } = req.body
        
        await torneoService.create(torneo,equipos)
        
        res.status(201).json({
            message : 'Torneo creado correctamente'
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

const update = async (req,res) => {
    try {
        await torneoService.update(req.body)
        res.status(200).json({
            message: 'Torneo actualizado correctamente'
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

module.exports = {
    index,
    store,
    update,
    show
}