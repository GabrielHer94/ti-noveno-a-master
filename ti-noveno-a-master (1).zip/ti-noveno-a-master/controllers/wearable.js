const { create } = require('../services/wearable')
const { findAll } = require('../repository/wearable')

const index = async (req,res) => {
    try {        
        const wearables = await findAll()
        res.status(200).json({
            wearables,
            total: wearables.length
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

const store = async (req,res) => {
    try {
        await create(req.body)
        res.status(201).json({
            message: 'Creado'
        })
    } catch (error) {
        res.status(500).json({
            message: 'Error, contacta al administrador'
        })
    }
}

module.exports = {
    index,
    store
}