const deporteRepository = require('../repository/deporte')
const deporteService = require('../services/deporte')

const index = async (req, res) => {
    try {
        const deportes = await deporteRepository.findAll(req.query)

        return res.status(200).json({
            deportes,
            total: deportes.length
        })   
    } catch (error) {
        console.log(error)
        res.status(500).json({
            message : 'Contacta con el administrador'
        })
    }
}

const show = async (req,res) => {
    try {
        let deporte = await deporteRepository.findByName(req.query.nombre)
        deporte = deporte || {}
        return res.status(200).json({
            deporte,
        })  
    } catch (error) {
        res.status(500).json({
            message : 'Contacta con el administrador'
        })
    }
} 

const store = async (req,res) => {
    try{
        const deporteCreado = await deporteService.create(req.body)
        res.status(201).json({
            message : 'Deporte guardado correctamente',
            deporte : deporteCreado
        })
    }catch(err){
        res.status(500).json({
            message : 'Contacta con el administrador'
        })
    }
}

const update = async (req, res) => {
    try{
        await deporteService.update(req.body)

        return res.status(200).json({
            message : 'Deporte actualizado correctamente',
        })
    }catch(err){
        return res.status(500).json({
            message : 'Error 501 Contacta al administrador'
        })
    }
}

const destroy = async (req,res) => {
    try{
        if(await deporteService.destroy(req.body.id)){
            return res.status(200).json({
                message : 'Deporte eliminado correctamente'
            })
        }
    }catch(err){
        return res.status(500).json({
            message : 'Error 500 Contacta al administrador'
        })
    }
    return res.status(404).json({
        message : 'Deporte no eliminado, pues no se ha podido encontrar'
    })
}

module.exports = {
    index,
    store,
    update,
    destroy,
    show
}