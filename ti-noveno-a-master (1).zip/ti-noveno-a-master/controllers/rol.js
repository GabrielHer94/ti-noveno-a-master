const rolService = require('../services/rol')

const index = async (req,res) => {
    try {
        const roles = await rolService.read(req.query)
        res.status(200).json({
            roles,
            total : roles.length
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

const store = async (req,res) =>{
    try {
        rolService.create(req.body)
        res.status(200).json({
            message : 'Rol creado correctamente' 
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

const update = async (req,res) => {
    try {
        await rolService.update(req.body)
        res.status(200).json({
            message : 'Rol actualizado correctamente' 
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
} 

module.exports = {
    index,
    store,
    update
}