const partidoRepository = require('../repository/partido')
const partidoService = require('../services/partido')

const index = async (req,res) => {
    try {
        const partidos = await partidoRepository.findAll(req.query)
        res.status(200).json({
            partidos,
            total : partidos.length
        })
    } catch (error) {
        console.log(error)
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

const store = async (req,res) => {
    try {
        await partidoService.create(req.body)
        res.status(201).json({
            message : 'partido creado correctamente'
        })
    } catch (error) {
        res.status(500).json({
            message : 'Error, contacta al administrador'
        })
    }
}

module.exports = {
    store,
    index
}