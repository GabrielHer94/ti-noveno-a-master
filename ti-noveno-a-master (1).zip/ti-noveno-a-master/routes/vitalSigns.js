const { index,store } = require('../controllers/vitalSigns')
const { Router } = require('express')

const router = Router()

router.get('/',index)
router.post('/',store)

module.exports = router