const { Router } = require('express')
const { index, store, update, destroy,show } = require('../controllers/deporte')
const checkJwt = require('../middleware/http/checkJwt')
const validate = require('../validate/deporte')
const router = Router()

router.get('/',index)
router.get('/show', show)
router.post('/',[checkJwt,validate.create],store)
router.patch('/',[checkJwt,validate.update],update)
router.delete('/',[checkJwt,validate.destroy],destroy)

module.exports = router