const { Router } = require('express')
const { index, store } = require('../controllers/wearable')

const router = Router()

router.get('/',index)
router.get('/',store)

module.exports = router