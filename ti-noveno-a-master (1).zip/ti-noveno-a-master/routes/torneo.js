const { Router } = require('express')
const { index, store, update, show } = require('../controllers/torneo')
const validate = require('../validate/torneo')
const checkJwt = require('../middleware/http/checkJwt')

const router = Router()

router.get('/', index)
router.get('/show', show)
router.post('/', [checkJwt, validate.create], store)
router.patch('/', [checkJwt, validate.update], update)

module.exports = router