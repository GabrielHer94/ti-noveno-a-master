const { Router }= require('express')
const { index, store, update } = require('../controllers/rol')
const validate = require('../validate/rol')

const router = Router()

router.get('/',index)
router.post('/',validate.create,store)
router.patch('/',validate.update,update)

module.exports = router