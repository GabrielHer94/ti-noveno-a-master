const { Router } = require('express')
const { index,store,update } = require('../controllers/permiso')
const checkPermission = require('../middleware/http/checkPermission')
const validate = require('../validate/permiso')

const router = Router()

router.get('/', index)
router.post('/',[ checkPermission('permiso.store'),validate.create ],store)
router.patch('/',validate.update,update)

module.exports = router