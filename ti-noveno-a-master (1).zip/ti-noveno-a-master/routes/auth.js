const { Router } = require('express')
const { login, register, update, index, store } = require('../controllers/auth')
const validate = require('../validate/auth')
const checkJwt = require('../middleware/http/checkJwt')
const checkPermission = require('../middleware/http/checkPermission')

const router = Router()

router.get('/',index)
router.post('/', [checkJwt, checkPermission('user.store'), validate.register], store)
router.post('/login',validate.login,login)
router.post('/register',validate.register,register)
router.patch('/update',validate.update,update)

module.exports = router