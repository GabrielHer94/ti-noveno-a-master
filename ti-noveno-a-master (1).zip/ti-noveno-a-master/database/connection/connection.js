const { Sequelize } = require('sequelize')
const config = require('../../config/database')

class Connection {
    static sequelize
    static create(){
        if(!Connection.sequelize){
            let configLocal = config[process.env.NODE_ENV || 'development']
            Connection.sequelize = new Sequelize(configLocal.database, configLocal.username, configLocal.password,{
                dialect : 'mysql',
                host : configLocal.host,
                port : configLocal.port || 3306
            })
        }
        return Connection.sequelize
    }   
    static close() {
        Connection.sequelize.close()
    } 
}

module.exports = Connection