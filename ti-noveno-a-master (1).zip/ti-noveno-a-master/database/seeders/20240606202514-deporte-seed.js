'use strict';
const formatter = require('../../helpers/formatter')
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */
    await queryInterface.bulkInsert('deportes',[
      {
        nombre : 'Futbol',
        deleted_at : null,
        created_at: formatter(),
        updated_at: formatter()
      }
    ]) 
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
    await queryInterface.bulkDelete('torneo_equipos',null,{})
    await queryInterface.bulkDelete('equipos',null,{})
    await queryInterface.bulkDelete('torneos',null,{})
    await queryInterface.bulkDelete('deportes',null,{})
  }
};
