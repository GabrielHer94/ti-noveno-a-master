'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('partidos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      equipo_uno_id: {
        type: Sequelize.INTEGER
      },
      equipo_dos_id: {
        type: Sequelize.INTEGER
      },
      torneo_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'torneos',
          key : 'id',
          onDelete: 'CASCADE',
          onUpdate: 'CASCADE',
        }
      },
      status : {
        type : Sequelize.BOOLEAN,
        defaultValue: true
      },
      deleted_at : {
        allowNull: true,
        type : Sequelize.DATE,
        defaultValue: Sequelize.NOW
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('partidos');
  }
};