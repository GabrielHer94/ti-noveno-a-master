'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('resultados', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      equipo_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'equipos',
          key : 'id',
          onDelete: 'CASCADE',
          onUpdate: 'CASCADE',
        }
      },
      puntaje: {
        type: Sequelize.INTEGER
      },
      partido_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'partidos',
          key : 'id',
          onDelete: 'CASCADE',
          onUpdate: 'CASCADE',
        }
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('resultados');
  }
};