'use strict';

const { DataTypes } = require('sequelize');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      nombre: {
        type: Sequelize.STRING
      },
      apellido_pat: {
        type: Sequelize.STRING
      },
      apellido_mat: {
        type: Sequelize.STRING
      },
      numero_tel: {
        type: Sequelize.STRING
      },
      password: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING,
        unique: true
      },
      deleted_at : {
        allowNull: true,
        type : Sequelize.DATE,
        defaultValue: DataTypes.NOW
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue : DataTypes.NOW
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue : DataTypes.NOW
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('users');
  }
};