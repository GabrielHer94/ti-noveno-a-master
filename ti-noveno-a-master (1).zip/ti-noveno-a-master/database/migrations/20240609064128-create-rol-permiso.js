'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('rol_permisos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      rol_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'rols',
          key : 'id',
          onUpdate : 'CASCADE',
          onDelete : 'CASCADE'
        }
      },
      permiso_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'permisos',
          key: 'id',
          onUpdate: 'CASCADE',
          onDelete : 'CASCADE'
        }
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('rol_permisos');
  }
};