'use strict';
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('equipos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      nombre: {
        type: Sequelize.STRING,
        unique: true
      },
      deporte_id: {
        type: Sequelize.INTEGER,
        references : {
          model : 'deportes',
          key : 'id',
          onUpdate : 'cascade'
        }
      },
      deleted_at : {
        allowNull: true,
        type : Sequelize.DATE,
        defaultValue: Sequelize.NOW
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('torneo_equipos')
    await queryInterface.dropTable('user_equipos')
    await queryInterface.dropTable('equipos');
  }
};