'use strict';

const { DataTypes } = require('sequelize');

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('torneos', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      nombre: {
        type: Sequelize.STRING
      },
      descripcion: {
        type: Sequelize.STRING
      },
      ubicacion: {
        type: Sequelize.STRING
      },
      fecha_inicio: {
        type: Sequelize.STRING
      },
      fecha_fin: {
        type: Sequelize.STRING
      },
      deporte_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'deportes',
          key: 'id',
          onUpdate: 'cascade'
        }
      },
      privado: {
        type: Sequelize.BOOLEAN
      },
      status : {
        type : Sequelize.BOOLEAN,
        defaultValue: true
      },
      deleted_at : {
        allowNull: true,
        type : Sequelize.DATE,
        defaultValue: DataTypes.NOW
      },
      created_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: DataTypes.NOW
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('torneos');
  }
};