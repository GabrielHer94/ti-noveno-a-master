const { hasPerm } = require('../../helpers/rol')
const jwt = require('jsonwebtoken')

const checkPermission = (permiso) => {
    return async (req,res,next) => {
        const token = req.header('Authorization')
        let user = null
        try {
            user = jwt.verify(token,process.env.SECRET_KEY)
        } catch (error) {
            return res.status(400).json({
                message : 'Error, token no valido'
            })
        }
        const result = await hasPerm(user,permiso)
        console.log(result)
        if(!result){
            return res.status(401).json({
                message : 'Error, usuario no authorizado'
            })
        }
        next()
    }
}

module.exports = checkPermission