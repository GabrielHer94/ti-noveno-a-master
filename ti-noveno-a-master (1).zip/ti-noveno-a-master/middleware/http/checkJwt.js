const jwt = require('jsonwebtoken')

const checkJwt = (req,res,next) => {
    const token = req.header('Authorization')
    if(token === undefined){
        return res.status(400).json({
            message : 'Token no proporcionado'
        })
    }
    try{
        jwt.verify(token,process.env.SECRET_KEY)
    }catch(err) {
        return res.status(400).json({
            message : 'Token invalido'
        })
    }
    next()
}

module.exports = checkJwt