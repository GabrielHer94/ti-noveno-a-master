'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class VitalSigns extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      VitalSigns.belongsTo(models.Wearable,{
        foreignKey: 'wearable_id'
      })
    }
  }
  VitalSigns.init({
    estres: DataTypes.INTEGER,
    ritmo_cardiaco: DataTypes.INTEGER,
    wearable_id : DataTypes.INTEGER,
    deleted_at : {
      type : DataTypes.DATE,
      defaultValue : null
    }
  }, {
    sequelize,
    modelName: 'VitalSigns',
    underscored: true,
    paranoid: true
  });
  return VitalSigns;
};