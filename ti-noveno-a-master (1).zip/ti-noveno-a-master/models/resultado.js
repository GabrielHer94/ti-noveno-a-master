'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Resultado extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Resultado.belongsTo(models.Equipo,{
        foreignKey : 'equipo_id',
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
      })
      Resultado.belongsTo(models.Partido,{
        foreignKey : 'partido_id',
        onDelete : 'CASCADE',
        onUpdate: 'CASCADE'
      })
    }
  }
  Resultado.init({
    equipo_id: {
      references: {
        model : 'Equipos',
        key : 'id',
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      },
      type: DataTypes.INTEGER
    },
    puntaje: DataTypes.INTEGER,
    partido_id: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Resultado',
    underscored: true
  });
  return Resultado;
};