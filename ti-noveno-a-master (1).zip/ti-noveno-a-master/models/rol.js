'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Rol extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Rol.belongsToMany(models.Permiso,{
        through: 'rol_permisos',
        foreignKey : 'rol_id',
        onDelete : 'CASCADE'
      })
      Rol.belongsToMany(models.User,{
        through : 'user_rols',
        foreignKey : 'rol_id',
        onDelete : 'CASCADE'
      })
    }
  }
  Rol.init({
    nombre: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Rol',
    paranoid: true,
    underscored: true
  });
  return Rol;
};