'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Partido extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Partido.belongsTo(models.Equipo,{
        foreignKey : 'equipo_uno_id',
        as : 'EquipoUno'
      })
      Partido.belongsTo(models.Equipo,{
        foreignKey : 'equipo_dos_id',
        as : 'EquipoDos'
      })
      Partido.belongsTo(models.Torneo,{
        foreignKey : 'torneo_id',
        onDelete : 'CASCADE',
        onUpdate: 'CASCADE'
      })
      Partido.hasMany(models.Resultado,{
        foreignKey: 'partido_id',
        onDelete : 'CASCADE',
        onUpdate: 'CASCADE'       
      })
    }
  }
  Partido.init({
    equipo_uno_id: {
      type : DataTypes.INTEGER,
      references : {
        model : 'Equipos',
        key : 'id',
        onDelete : 'CASCADE',
        onUpdate: 'CASCADE'
      }
    },
    equipo_dos_id: {
      type : DataTypes.INTEGER,
      references : {
        model : 'Equipos',
        key : 'id',
        onDelete : 'CASCADE',
        onUpdate: 'CASCADE'
      }
    },
    status : {
      type : DataTypes.INTEGER,
      get() {
        const status = this.getDataValue('status')
        if(status === 0){
          return 'finalizado'
        }else if(status === 1){
          return 'pendiente'
        }
        return 'en juego'
      },
      set(value) {
        if(value === 'finalizado'){
          this.setDataValue('status',0)
        }else if(value === 'pendiente'){
          this.setDataValue('status',1)
        }else {
          this.setDataValue('status',2)
        }
      }
    },
    torneo_id: {
      type : DataTypes.INTEGER,
    }
  }, {
    sequelize,
    modelName: 'Partido',
    paranoid: true,
    underscored: true
  });
  return Partido;
};