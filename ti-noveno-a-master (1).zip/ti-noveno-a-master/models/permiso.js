'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Permiso extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Permiso.belongsToMany(models.Rol,{
        through : 'rol_permisos',
        foreignKey : 'permiso_id',
        onDelete : 'cascade'
      })
    }
  }
  Permiso.init({
    id : {
      type : DataTypes.INTEGER,
      primaryKey : true,
      autoIncrement : true
    },
    nombre: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Permiso',
    paranoid: true,
    underscored: true
  });
  return Permiso;
};