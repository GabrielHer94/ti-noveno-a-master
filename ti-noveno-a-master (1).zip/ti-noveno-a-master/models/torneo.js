const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Torneo extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
    */
    static associate(models) {
      // define association here
      Torneo.belongsTo(models.Deporte, {
        foreignKey: 'deporte_id',
        onDelete: 'CASCADE'
      })
      Torneo.belongsToMany(models.Equipo, {
        through: 'torneo_equipos',
        foreignKey: 'torneo_id',
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE',
      })
    }
  }
  Torneo.init({
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    nombre: {
      unique: true,
      type: DataTypes.STRING
    },
    descripcion: DataTypes.STRING,
    ubicacion: DataTypes.STRING,
    fecha_inicio: DataTypes.STRING,
    fecha_fin: DataTypes.STRING,
    deporte_id: DataTypes.INTEGER,
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: true
    },
    privado: DataTypes.BOOLEAN
  }, {
    sequelize,
    modelName: 'Torneo',
    underscored: true,
    paranoid: true
  });
  return Torneo;
};