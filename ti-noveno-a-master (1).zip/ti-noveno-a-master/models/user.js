'use strict';
const {
  Model
} = require('sequelize');
const crypt = require('../helpers/crypt')
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      User.belongsToMany(models.Rol,{
        through: 'user_rols',
        foreignKey: 'user_id',
        onDelete : 'CASCADE'
      })
    }
  }
  User.init({
    nombre: DataTypes.STRING,
    apellido_pat: DataTypes.STRING,
    apellido_mat: DataTypes.STRING,
    numero_tel: DataTypes.STRING,
    password: {
      type : DataTypes.STRING,
      set(value){
        this.setDataValue('password',crypt.hash(value))
      }
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      validate: {
        isEmail: true
      }
    }
  }, {
    sequelize,
    modelName: 'User',
    paranoid: true,
    underscored: true
  });
  return User;
};