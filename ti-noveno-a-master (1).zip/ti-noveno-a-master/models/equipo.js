'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Equipo extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Equipo.belongsTo(models.Deporte,{
        foreignKey : 'deporte_id'
      })
      Equipo.belongsToMany(models.Torneo,{
        through : 'torneo_equipos',
        foreignKey : 'torneo_id',
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
      })
    }
  }
  Equipo.init({
    id: {
      type: DataTypes.INTEGER,
      primaryKey : true,
      autoIncrement: true
    },
    nombre: DataTypes.STRING,
    deporte_id: DataTypes.INTEGER,
  }, {
    sequelize,
    modelName: 'Equipo',
    paranoid: true,
    underscored: true
  });
  return Equipo;
};