'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Wearable extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Wearable.belongsTo(models.User)
      Wearable.hasMany(models.VitalSigns)
    }
  }
  Wearable.init({
    model: DataTypes.STRING,
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    ip_address: DataTypes.STRING,
    user_id : DataTypes.INTEGER,
  }, {
    sequelize,
    modelName: 'Wearable',
    underscored: true
  });
  return Wearable;
};