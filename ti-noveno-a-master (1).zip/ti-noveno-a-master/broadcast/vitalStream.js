const session = require('../helpers/session')
const vitalSignsRepository = require('../repository/vitalSigns')
const wearableRepository = require('../repository/wearable')
const { create, notifyToClients } = require('../services/vitalSigns')

module.exports = (io) => {
    io.on('connect',(socket) => {
        socket.on('fetch-data',async () => {
            const wearables = await wearableRepository.findAll()
            socket.emit('take-data', wearables)
        })
        socket.on('fetch-last-data', async (id) => {
            const wearableLastInfo = await wearableRepository.findById(id)
            socket.emit('take-last-vital-sign',wearableLastInfo)
        })
        socket.on('push-data',async (vitalSigns) => {
            await create(vitalSigns)
            notifyToClients(io)
        })
        socket.on('connect-wearable',async (id) => {
            session.set('id',id)
            await wearableRepository.update({
                status : 1
            },id)
            const wearables = await wearableRepository.findAll()
            io.emit('changed', wearables)
            socket.emit('response','wearable conectado')
        })
        socket.on('disconnect', async () => {
            const wearableId = session.get('id')
            if(wearableId){
                await wearableRepository.update({
                    status : 0
                },wearableId)
                const wearables = await wearableRepository.findAll()
                io.emit('changed', wearables)
            }
        })
    })
}