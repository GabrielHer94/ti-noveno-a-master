const { User, Rol, Permiso } = require('../models')

const hasPerm = async (user,permiso) => {
    const model = await User.findOne({
        where : {
            id : user.id
        },
        include: [
            {
                model : Rol,
                include : Permiso
            }
        ]
    })
    console.log(user.id)
    if(!model){
        return false
    }
    const roles = model.Rols
    if(!roles){
        return false
    }
    const permisosFromUserRols = []
    roles.forEach(rol => {
        permisosFromUserRols.push(...rol.Permisos)
    })
    const result = permisosFromUserRols.find(permisoFromUserRol => permisoFromUserRol.nombre === permiso)
    return result !== undefined
}

module.exports = {
    hasPerm
}