const bcrypt = require('bcrypt')

/**
 * 
 * @param {*} data 
 * @returns 
 */
const hash = (data) => {
    return bcrypt.hashSync(data,bcrypt.genSaltSync(10))
}
/**
 * 
 * @param {*} data 
 * @param {*} hash 
 * @returns 
 */
const compare = (data,hash) => {
    return bcrypt.compareSync(data,hash)
}

module.exports = {
    hash,
    compare
}