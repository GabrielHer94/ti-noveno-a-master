const failure = (message,fields) => {
    return {
        message,
        fields
    }
}

module.exports = {
    failure,
}