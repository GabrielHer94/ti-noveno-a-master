const { Sequelize } = require('sequelize')
const Connection = require('../database/connection/connection')

const exists = async (field,value,tableName) => {
    const myConn = Connection.create()
    const [results, metadata]= await myConn.query(`SELECT ${field} FROM ${tableName} WHERE ${field} = :${field}`, {
        replacements: { [field]: value },
        type: Sequelize.QueryTypes.SELECT
    })
    return results !== null && results !== undefined
}   

module.exports = exists