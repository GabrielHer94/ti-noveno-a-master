const success = (value) => {
    return {
        isSuccess : true,
        value,
        error: null
    }
}

const failure = (error) => {
    return {
        isSuccess : false,
        value: null,
        error
    }
}

module.exports = {
    success,
    failure
}