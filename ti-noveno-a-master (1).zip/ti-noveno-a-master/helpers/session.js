class Session {
    static data = []

    static set(key,value) {
        Session.data.push({ key,value })
    }
    static get(key){
        return Session.data.find((element => key === element.key))?.value
    }
}

module.exports = Session