require('dotenv').config()
const http = require('http')
const socketIo = require('socket.io')
const express = require('express')
const Connection = require('../database/connection/connection')
const cors = require('cors')
const Session = require('../helpers/session')

class App {
    static db = Connection.create()
    static session = Session
    
    constructor(){
        this.port = process.env.PORT
        this.app = express()
        this.server = http.createServer(this.app)
        this.io = socketIo(this.server,{
            cors: {
                origin: [
                    'http://localhost:5173',
                    'http://localhost:30000'
                ],
            }
        })
        this.middlewares()
        this.routes()
    }

    broadcast() {
        require('../broadcast/vitalStream')(this.io)
    }

    middlewares(){
        this.app.use(express.json())
        this.app.use(cors({
            origin: [
                'http://localhost:5173',
                'http://localhost:6017',
                'http://localhost:30000'
            ],
        }))
    }
    
    routes(){
        this.app.use('/deportes',require('../routes/deporte'))
        this.app.use('/auth',require('../routes/auth'))
        this.app.use('/torneos',require('../routes/torneo'))
        this.app.use('/permisos',require('../routes/permiso'))
        this.app.use('/roles',require('../routes/rol'))
        this.app.use('/vital-signs',require('../routes/vitalSigns'))
        this.app.use('/partidos',require('../routes/partido'))
        this.app.use('/wearables',require('../routes/wearable'))
        this.app.use('/equipos',require('../routes/equipo'))
        this.broadcast()
    }

    close(){
        App.db.close()
        this.server.close()
    }

    listen(){
        this.server.listen(this.port,() => {
            console.log('Escuchando el puerto: ', this.port)
        })
    }
}

module.exports = App
