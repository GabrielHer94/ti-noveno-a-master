const { User } = require('../models')

const findById = async (id) => {
    return await User.findOne({
        where : {
            id
        }
    })
}

const find = async ({where,limit = 1000,offset = 0}) => {
    return await User.findAll({
        where,
        limit,
        offset
    })
}

const findByEmail = async (email) => {
    return await User.findOne({
        where : {
            email
        }
    })
}

const findAll = async () => {
    return await User.findAll({
        attributes : { exclude : ['password'] }
    })
}

const save = async (user) => {
    const userObj = User.build(user)
    return await userObj.save()
}

module.exports = {
    findByEmail,
    save,
    findById,
    findAll,
    find
}