const { Wearable,VitalSign } = require('../models')

const findAll = async () => {
    return await Wearable.findAll()
}

const findById = async (id) => {
    return await Wearable.findOne({
        where : { id },
        include: VitalSign
    })
}

const save = async (wearable) => {
    const wearableModel = await Wearable.build(wearable)
    return await wearableModel.save()
}

const update = async (wearable,id) => {
    const wearableModel = await Wearable.findOne({
        where : { id }
    })
    wearableModel.update(wearable)
}

module.exports = {
    findAll,
    findById,
    save,
    update
}