const { Torneo, Equipo, Deporte }= require('../models')

const findAll = async ({ limit = 100, offset = 0, nombre }) => {
    const queryOptions = {
        where: {},
        limit: parseInt(limit),
        offset: parseInt(offset),
        include : [
            {
                model:Equipo
            },
            {
                model: Deporte
            }
        ],
    }
    if (nombre) {
        queryOptions.where.nombre = {
            [Op.like]: `%${nombre}%`,
        }
    }
    return await Torneo.findAll(queryOptions)
}

const save = async (torneo) => {
    const torneoBuild = Torneo.build(torneo)
    return await torneoBuild.save()
}

const update = async (newValues,args) => {
    const torneo = await Torneo.findOne({
        where: {
            id : args.id
        }
    })
    const affectedRows = torneo.update(newValues)
    return affectedRows
}

const destroy = async (id,force = false) => {
    await Torneo.destroy({
        where: { id },
        force
    })
}

const findById = async (id) => {
    return await Torneo.findOne({
        where :{id},
        include : [
            {
                model:Equipo
            },
            {
                model: Deporte
            }
        ],
    })
}

const findByName = async (nombre) => {
    return await Torneo.findOne({
        where : {
            nombre,
        }
    })
}

module.exports = {
    findAll,
    save,
    update,
    findByName,
    findById,
    destroy
}