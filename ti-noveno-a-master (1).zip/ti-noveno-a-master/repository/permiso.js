const { Permiso } = require('../models')

const findByName = async (nombre) => {
    return await Permiso.findOne({
        where : {
            nombre
        }
    })
}

const findById = async (id) => {
    return await Permiso.findOne({
        where: {
            id
        }
    })
}

const findAll = async () => {
    return await Permiso.findAll()
}

const save = async (permiso) => {
    const newPermiso = await Permiso.build(permiso)
    return await newPermiso.save()
}

const update = async (newValues,args) => {
    const newPermiso = await Permiso.findOne({
        where: args
    })
    await newPermiso.update(newValues)
}

module.exports = {
    findAll,
    save,
    update,
    findByName,
    findById
}