const { Rol,Permiso } = require('../models')

const findById = async (id) => {
    return await Rol.findOne({
        where : {id},
        include : Permiso
    })
}

const findAll = async () => {
    return await Rol.findAll()
}

const findByName = async (nombre) => {
    const rol = await Rol.findOne({
        where : {
            nombre
        }
    })
    return rol
}

const save = async (rol) => {
    const newRol =await Rol.build(rol)
    return await newRol.save()
}

const update = async (newValues,args) => {
    const rol = await Rol.findOne({
        where: {
            id : args.id
        }
    })
    await rol.update(newValues)
}

module.exports = {
    findByName,
    findAll,
    save,
    update,
    findById
}