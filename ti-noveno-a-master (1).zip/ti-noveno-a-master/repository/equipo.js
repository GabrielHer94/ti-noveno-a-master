const { Op } = require('sequelize')
const { Equipo } = require('../models')
 
const findAll = async ({ limit = 100, offset = 0, nombre}) => {
    const queryOptions = {
        where: {},
        limit : parseInt(limit),
        offset: parseInt(offset)
    }
    if(nombre) {
        queryOptions.where.nombre = {
            [Op.like] : `%${nombre}%`
        }
    }
    return await Equipo.findAll(queryOptions)
}

const findById = async (id) => {
    return await Equipo.findOne({
        where : {
            id
        }
    })
}

const destroy = async (id,force = false) => {
    await Equipo.destroy({
        where: { 
            id 
        },
        force
    })
}

const save = async (equipo) => {
    const newEquipo = await Equipo.build(equipo)
    return await newEquipo.save()
}

module.exports = {
    findAll,
    save,
    findById,
    destroy
}