const { Op } = require('sequelize')
const { Partido,Resultado,Equipo } = require('../models')

const findAll = async ({ limit = 100, offset = 0, nombre }) => {
    const queryOptions = {
        where: {},
        include : [
            {
                model: Equipo,
                as: 'EquipoUno',
            },
            {
                model: Equipo,
                as: 'EquipoDos',
            },
            {
                model: Resultado
            }
        ],
        limit: parseInt(limit),
        offset: parseInt(offset)
    }
    if (nombre) {
        queryOptions.where.nombre = {
            [Op.like]: `%${nombre}%`,
        }
    }
    return await Partido.findAll(queryOptions)
}

const save = async (partido) => {
    const partidoBuild = await Partido.build(partido)
    return await partidoBuild.save()
}

module.exports = {
    save,
    findAll
}   