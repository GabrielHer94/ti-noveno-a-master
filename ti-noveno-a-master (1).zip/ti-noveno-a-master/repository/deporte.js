const { Op } = require('sequelize')
const { Deporte } = require('../models')

const findById = async (id) => {
    return await Deporte.findOne({
        where : {
            id
        }
    })
}

const findByName = async (nombre) => {
    return await Deporte.findOne({
        where : {
            nombre
        }
    })
}

const destroy = async(id,force = false) => {
    await Deporte.destroy({
        where : {
            id
        },
        force
    })
}

const findAll = async ({ limit = 100, offset = 0, nombre}) => {
    const queryOptions= {
        where : {},
        limit: parseInt(limit),
        offset: parseInt(offset)
    }
    if(nombre) {
        queryOptions.where.nombre = {
            [Op.like] : `%${nombre}%`    
        }
    }
    return await Deporte.findAll(queryOptions)
}

const save = async (nombre) => {
    const deporte = Deporte.build({nombre})
    return await deporte.save()
}

const deleteAll = async () => {
    const affectedRows = await Deporte.destroy({
        where: {},
        truncate: true
    })
    return affectedRows
}
/**
 * 
 * @param {*} deporte 
 * @param {*} args 
 */
const update = async (deporte,where) => {
    const affectedRows = await Deporte.update(deporte,{
        where
    })
    return affectedRows
}

module.exports = {
    findAll,
    save,
    deleteAll,
    update,
    findById,
    findByName,
    destroy
}