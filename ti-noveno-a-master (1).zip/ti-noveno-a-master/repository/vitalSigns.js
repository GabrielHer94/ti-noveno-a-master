const { Wearable } = require('../models')
const { VitalSigns } = require('../models')

const findOne = async () => {
    return await VitalSigns.findOne({
        include: Wearable
    })
}

const findByWearableId = async (wearableId) => {
    return await VitalSigns.findOne({
        where: { wearable_id : wearableId }
    })
}

const findAll = async () => {
    return await VitalSigns.findAll({
        include: Wearable
    })
}

const save = async (vitalSigns) => {
    const vitalSignsModel = await VitalSigns.build(vitalSigns)
    return await vitalSignsModel.save()
}

const update = async (id,vitalSigns) => {
    const vitalSignsModel = await VitalSigns.update(vitalSigns,{
        where : { id }
    })
    return vitalSignsModel
}

module.exports = {
    save,
    update,
    findAll,
    findByWearableId,
    findOne
}